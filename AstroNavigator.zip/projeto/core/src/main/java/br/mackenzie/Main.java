package br.mackenzie;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class Main implements ApplicationListener {
    Texture naveTexture;
    Texture asteroidTexture;
    Texture backgroundTexture;

    SpriteBatch spriteBatch;
    FitViewport viewport;
    Sprite naveSprite;

    Vector2 touchPos;
    Array<Sprite> asteroidSprites;

    float asteroidTimer;

    @Override
    public void create() {
        naveTexture = new Texture("nave.png");
        asteroidTexture = new Texture("asteroid.png");
        backgroundTexture = new Texture("background.png");

        spriteBatch = new SpriteBatch();
        viewport = new FitViewport(8, 5);

        naveSprite = new Sprite(naveTexture);
        naveSprite.setSize(1, 1); // tamnho da nave

        touchPos = new Vector2();
        asteroidSprites = new Array<>();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true); // atualiza a viewport
    }

    @Override
    public void render() {
        input();   
        logic();   
        draw();    
    }

    private void input() {
        float speed = 4f;
        float delta = Gdx.graphics.getDeltaTime();

        // mov pelo teclado
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            naveSprite.translateX(speed * delta);
        } else if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            naveSprite.translateX(-speed * delta);
        } else if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            naveSprite.translateY(speed * delta);
        } else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            naveSprite.translateY(-speed * delta);
        }

        //  mouse
        if (Gdx.input.isTouched()) {
            touchPos.set(Gdx.input.getX(), Gdx.input.getY());
            viewport.unproject(touchPos); 
            naveSprite.setCenterX(touchPos.x);
            naveSprite.setCenterY(touchPos.y);
        }
    }

    private void logic() {
        float worldWidth = viewport.getWorldWidth();
        float worldHeight = viewport.getWorldHeight();
        float naveWidth = naveSprite.getWidth();
        float naveHeight = naveSprite.getHeight();

        // limita nave pra nao sair da tela
        naveSprite.setX(MathUtils.clamp(naveSprite.getX(), 0, worldWidth - naveWidth));
        naveSprite.setY(MathUtils.clamp(naveSprite.getY(), 0, worldHeight - naveHeight));

        float delta = Gdx.graphics.getDeltaTime();
        for (int i = asteroidSprites.size - 1; i >= 0; i--) {
            Sprite asteroid = asteroidSprites.get(i);
            asteroid.translateY(-2f * delta);

            // colisao com nave - some da tela
            if (asteroid.getBoundingRectangle().overlaps(naveSprite.getBoundingRectangle())) {
                asteroidSprites.removeIndex(i);
            }
        }

        // cria novos asteroides
        asteroidTimer += delta;
        if (asteroidTimer > 1f) {
            asteroidTimer = 0;
            createAsteroid();
        }
    }

    private void draw() {
        ScreenUtils.clear(Color.BLACK);
        viewport.apply();
        spriteBatch.setProjectionMatrix(viewport.getCamera().combined);

        spriteBatch.begin();

        float worldWidth = viewport.getWorldWidth();
        float worldHeight = viewport.getWorldHeight();

        spriteBatch.draw(backgroundTexture, 0, 0, worldWidth, worldHeight); // fundo
        naveSprite.draw(spriteBatch);

        for (Sprite asteroid : asteroidSprites) {
            asteroid.draw(spriteBatch); // desenha os asteroids
        }

        spriteBatch.end();
    }

    private void createAsteroid() {
        float asteroidWidth = 1;
        float asteroidHeight = 1;
        float worldWidth = viewport.getWorldWidth();
        float worldHeight = viewport.getWorldHeight();

        Sprite asteroid = new Sprite(asteroidTexture);
        asteroid.setSize(asteroidWidth, asteroidHeight);
        asteroid.setX(MathUtils.random(0f, worldWidth - asteroidWidth));
        asteroid.setY(worldHeight);
        asteroidSprites.add(asteroid); // add na lista
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {
        naveTexture.dispose();
        asteroidTexture.dispose();
        backgroundTexture.dispose();
        spriteBatch.dispose();
    }
}
